import sys
import pandas as pd
import os
import re
import pickle
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import nltk
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
from sqlalchemy import create_engine
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report
from sklearn.multioutput import MultiOutputClassifier
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score

def load_data(database_filepath):
    """
    Function to load data from the previously created database

    Input:
        database_filepath: path from the database

    Returns:
        X : dataframe with the features
        y : datafram with labels
        category_names: List with the names of the categories
    """
    engine = create_engine('sqlite:///'+ database_filepath)
    df = pd.read_sql_table('ETLTable', engine)
    X = df['message']
    Y = df.drop(['id','message','original','genre'],axis=1)
    category = Y.columns
    return X,Y, category

def tokenize(text):
    """
    Function to process text with tokenize and lemmatize function.

    Input:
        text: data to be processed

    Returns:
        clean_tokens: list with tokens extracted from the processed text 
    """

    url_regex = 'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
    detected_urls = re.findall(url_regex, text)
    for url in detected_urls:
        text = text.replace(url, "urlplaceholder")

    tokens = word_tokenize(text)
    lemmatizer = WordNetLemmatizer()
    
    clean_tokens = []
    for tok in tokens:
        clean_tok = lemmatizer.lemmatize(tok).lower().strip()
        clean_tokens.append(clean_tok)
    return clean_tokens

def build_model():
    """
    Function to build the machine learning model.
    
    Inputs:
        None

    Returns:
        cv: model based on a pipeline with gridsearch.
        
    """
    moc = MultiOutputClassifier(RandomForestClassifier())
    pipeline = Pipeline([
            ('vect', CountVectorizer(tokenizer=tokenize)),
            ('tfidf', TfidfTransformer()),
            ('clf', moc)
    ])
    parameters = {'clf__estimator__max_depth': [10, 50, None],
                  'clf__estimator__min_samples_leaf':[2, 5, 10]}

    #cv = GridSearchCV(estimator=pipeline, param_grid=parameters, cv=3, verbose=2)
    model = GridSearchCV(estimator=pipeline, param_grid=parameters, cv=3, verbose=2)

   # cv.fit(X_train.as_matrix(), y_train)
   # return cv
    return model


#def evaluate_model(model, X_test, Y_test, category_names):
def evaluate_model(model, X_test, Y_test, category_names):
    """
    Function to evaluate the previously built model.
    
    Input:
        model: ML pipeline model
        X_test: features test data
        Y_test: labels test data
        category_names: List of category names
    
    Returns:
        None
    """
    y_pred_df = model.predict(X_test)
    
    for i, category in enumerate(category_names):
        accuracy = accuracy_score(Y_test.iloc[:, i], y_pred_df[:, i])
        precision = precision_score(Y_test.iloc[:, i], y_pred_df[:, i], average='weighted')
        recall = recall_score(Y_test.iloc[:, i], y_pred_df[:, i], average='weighted')
        f1 = f1_score(Y_test.iloc[:, i], y_pred_df[:, i], average='weighted')

        print(f"Category: {category}")
        print(f"\tAccuracy: {accuracy:.4f}")
        print(f"\tPrecision: {precision:.4f}")
        print(f"\tRecall: {recall:.4f}")
        print(f"\tF1 Score: {f1:.4f}")
        print("\n", classification_report(Y_test.iloc[:, i], y_pred_df[:, i]))
        
    #classification report with new y predicted
    def classreport(Y_test, y_pred_df):
        """
        Function to show main classification metrics.
        
        Inputs:
            Y_test:labels test data
            y_pred_df:predicted labels test data
        
        Returns:
            None
        """
        
        #for i, col in enumerate(Y_test.columns): 
        for i, col in enumerate(category_names): 
            print(' ')
            print(col)
            print(classification_report(Y_test.iloc[:,i], y_pred_df[:,i]))
 

        
    # print accuracy score
    #print('Accuracy: {}'.format(np.mean(Y_test.values == y_pred_df)))
    
def save_model(model, model_filepath):
    """
    Function to solve the pipeline
    Inputs:
        model: ML Pipeline model
        model_filepath: Path to the model path
    Returns:
        None
    """
    with open(model_filepath, 'wb') as file:
        pickle.dump(model, file)

def main():
    if len(sys.argv) == 3:
        database_filepath, model_filepath = sys.argv[1:]
        print('Loading data...\n    DATABASE: {}'.format(database_filepath))
        X, Y, category_names = load_data(database_filepath)
        X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)
        
        # EVA - Verify the tokenization
        print(f'Example tokenization: {tokenize(X.iloc[0])}')
        
        # EVA - Check train / test sample
        X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)
        print(f'Split data into {X_train.shape[0]} training and {X_test.shape[0]} testing samples.')
        
        # Verificar características generadas por CountVectorizer
        vect = CountVectorizer(tokenizer=tokenize)
        X_train_counts = vect.fit_transform(X_train)
        print(f'Vectorized train data shape: {X_train_counts.shape}')
        
        # Continuar con el pipeline y GridSearchCV si la verificación es exitosa
        print('Building model...')
        model = build_model()
        
        print('Training model...')
        model.fit(X_train, Y_train)
        
        print('Evaluating model...')
        evaluate_model(model, X_test, Y_test, category_names)

        print('Saving model...\n    MODEL: {}'.format(model_filepath))
        save_model(model, model_filepath)

        print('Trained model saved!')

    else:
        print('Please provide the filepath of the disaster messages database '\
              'as the first argument and the filepath of the pickle file to '\
              'save the model to as the second argument. \n\nExample: python '\
              'train_classifier.py ../data/DisasterResponse.db classifier.pkl')


if __name__ == '__main__':
    main()